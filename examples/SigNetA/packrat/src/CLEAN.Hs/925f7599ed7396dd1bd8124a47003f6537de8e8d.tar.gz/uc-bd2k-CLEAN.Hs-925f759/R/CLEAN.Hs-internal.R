.fTreeViewPath <-
"/usr/local/lib64/R/library/CLEAN/doc/"
