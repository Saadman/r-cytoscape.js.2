CLEAN.Hs <-
function() c("BioGRID", "chrLoc", "CpGislands", "ESR1targets", "geneRIFs", "GO", "GSEA", "HUGE", "KEGG", "L2L", "MeshTable", "methylome", "modules", "MP", "reactome", "transfac","CTD","tfacts")

